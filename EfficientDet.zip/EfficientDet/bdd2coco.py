import os
import json
from PIL import Image

# The directory of your JSON files
json_directory = 'D:/BDD_dataset/download/split_json/val/'

# The directory of your images
image_directory = 'D:/BDD_dataset/download/bdd100k/images/100k/val/'

# Your categories
category_list = ['car', 'bus', 'person', 'bike', 'truck', 'motor', 'train', 'rider', 'traffic sign', 'traffic light']
categories = [{"id": i+1, "name": name} for i, name in enumerate(category_list)]

# Prepare the COCO data
coco_data = {
    "images": [],
    "annotations": [],
    "categories": categories,
}


# Loop over all JSON files
for filename in os.listdir(json_directory):
    if filename.endswith('.json'):
        with open(os.path.join(json_directory, filename), 'r') as f:
            data = json.load(f)

            # Add the image information
            image_id = len(coco_data["images"]) + 1
            image = Image.open(os.path.join(image_directory, data["name"]))
            image_info = {
                "id": image_id,
                "file_name": data["name"],
                "width": image.width,
                "height": image.height, 
            }
            coco_data["images"].append(image_info)

            # Add the annotations
            for label in data["labels"]:
            
                if label["category"] not in category_list:
                   continue
                annotation = {
                    "id": len(coco_data["annotations"]) + 1,
                    "image_id": image_id,
                    "category_id": [c["id"] for c in categories if c["name"] == label["category"]][0],
                    "bbox": [label["box2d"]["x1"], label["box2d"]["y1"], label["box2d"]["x2"] - label["box2d"]["x1"], label["box2d"]["y2"] - label["box2d"]["y1"]],
                    "area": (label["box2d"]["x2"] - label["box2d"]["x1"]) * (label["box2d"]["y2"] - label["box2d"]["y1"]),
                    "iscrowd": 0,
                }
                coco_data["annotations"].append(annotation)
# 
# Write the COCO data to a JSON file
with open('val.json', 'w') as f:
    json.dump(coco_data, f)
